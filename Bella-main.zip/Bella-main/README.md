Homework 5, Question 2. Interpreter for the Bella extension in Typescript.
